@echo off
REM Double-cliquer UNE FOIS sur ce fichier : il cree le raccourci "Warehouse DF"
REM (avec le logo) sur le Bureau. Ensuite, on lance l'application avec ce raccourci.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$dir = (Get-Location).Path; $sh = New-Object -ComObject WScript.Shell; $desk = [Environment]::GetFolderPath('Desktop'); $lnk = $sh.CreateShortcut((Join-Path $desk 'Warehouse DF.lnk')); $lnk.TargetPath = (Join-Path $dir 'LANCER.bat'); $lnk.WorkingDirectory = $dir; $lnk.IconLocation = (Join-Path $dir 'static\warehouse.ico') + ',0'; $lnk.Description = 'Warehouse DF'; $lnk.Save()"
if errorlevel 1 (
  echo Le raccourci n'a pas pu etre cree.
) else (
  echo Raccourci "Warehouse DF" cree sur le Bureau.
  echo Si le dossier de l'application est deplace, relancez ce fichier.
)
pause
