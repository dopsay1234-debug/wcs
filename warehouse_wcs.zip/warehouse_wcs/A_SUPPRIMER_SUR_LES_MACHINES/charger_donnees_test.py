"""Charge le tableau de stock de test (donnees_test/stock_initial.tsv) dans stock.db.

Format : une ligne par article, une colonne par palette (P1, P2, ...), la quantité
dans la case. Les lignes TOTAL et de comptage sont ignorées.
Une palette contient au maximum 100 pièces : une quantité au-delà est remplacée
par une valeur aléatoire entre 1 et 100 (données de test uniquement).
Les articles déjà présents dans la base sont laissés tels quels.
"""

import os
import random
import sys

# app.py et stock.py sont dans le dossier parent
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import DB_PATH
from stock import Stock

MAX_PIECES = 100
FICHIER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "donnees_test", "stock_initial.tsv")


def lire(path, rng):
    with open(path, encoding="utf-8") as f:
        lignes = [l.rstrip("\r\n").split("\t") for l in f]
    entete = lignes[0]
    palettes = {i: nom.strip() for i, nom in enumerate(entete) if nom.strip().upper().startswith("P")}
    articles = []
    for ligne in lignes[1:]:
        nom = ligne[0].strip()
        if not nom or nom.upper() == "TOTAL":
            continue
        contenu = []
        for i, palette in palettes.items():
            case = ligne[i].strip() if i < len(ligne) else ""
            if not case:
                continue
            qty = int(case)
            if qty > MAX_PIECES:
                qty = rng.randint(1, MAX_PIECES)
            if qty > 0:
                contenu.append({"palette": palette, "qty": qty})
        articles.append((nom, contenu))
    return articles


def main():
    rng = random.Random(42)  # mêmes valeurs aléatoires à chaque chargement
    stock = Stock(DB_PATH)
    deja = {a["name"].lower() for a in stock.search("", limit=100000)}
    ajoutes = ignores = 0
    for nom, palettes in lire(FICHIER, rng):
        if " ".join(nom.split()).lower() in deja:
            ignores += 1
            continue
        stock.create_article(nom, palettes)
        ajoutes += 1
    stock.close()
    print(f"Base : {DB_PATH}")
    print(f"{ajoutes} article(s) ajouté(s), {ignores} déjà présent(s).")


if __name__ == "__main__":
    sys.exit(main())
