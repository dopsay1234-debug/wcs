@echo off
REM Double-cliquer pour ajouter les articles de test dans la base (stock.db)
cd /d "%~dp0"
where py >nul 2>nul && (py charger_donnees_test.py & goto :fin)
where python >nul 2>nul && (python charger_donnees_test.py & goto :fin)
echo Python n'est pas installe sur ce PC : https://www.python.org/downloads/
:fin
pause
