# Stock Duty Free

> **Ce dossier (`A_SUPPRIMER_SUR_LES_MACHINES`) n'est pas nécessaire pour faire tourner l'application.**
> Il contient la documentation, les tests, la maquette et les données de test.
> Sur les PC de l'entrepôt, on peut le supprimer : il suffit de garder `LANCER.bat`, `CREER_RACCOURCI.bat`, `app.py`, `stock.py` et le dossier `static`.

Application de suivi de stock par article et par palette, pensée pour un écran tactile. Tout se compte **à la pièce**.

- **Réceptions** : au premier article ajouté, une fenêtre demande le **numéro de PO** et la **date de réception réelle** (aujourd'hui par défaut, jamais dans le futur ; modifiables ensuite en touchant le numéro au-dessus des cartes). On cherche un article ; pour chaque palette on voit le stock actuel, on tape au clavier le nombre de pièces à ajouter et on voit le stock après.
  Le **+** sous les palettes ajoute une nouvelle palette (impossible d'ajouter une palette que l'article a déjà). **Valider** fonctionne aussi sans quantité.
- **Sortie** : au premier article ajouté, une fenêtre demande le **numéro d'OF** (modifiable ensuite en touchant le numéro au-dessus de la liste). Une ligne par article, sur la palette qui a le moins de pièces : stock actuel, pièces à retirer (tapées au clavier), restant.
  Si la quantité demandée dépasse le stock de cette palette, l'application passe automatiquement à la palette la moins remplie qui suffit et l'indique par un message.
  Aucune palette ne suffit : la quantité est limitée au stock de la palette la plus remplie.
- **Inventaire** (mot de passe `Newrest2026`, verrouillage automatique après 1 h ou avec le bouton cadenas, qui ramène sur Réceptions) :
  toutes les palettes avec leur contenu. On glisse un article (poignée ⠿) de la liste ou d'une palette vers une autre palette pour l'ajouter ou le déplacer,
  on touche une quantité pour la corriger, on touche un article de la liste pour voir ses palettes. Glisser un article de la liste vers la droite fait apparaître **SUPPRIMER**
  (retrait du catalogue avec son stock, après confirmation) : c'est le seul onglet où c'est possible.
- **Historique** : tous les événements (ajout/suppression d'article, réception, sortie, correction d'inventaire, déplacement, changement de numéro de palette, palette vidée), filtrables. Les événements d'une même validation sont **regroupés** dans une carte (ex. toute une réception avec son PO et sa date réelle, ou toute une sortie avec son OF) ; la recherche trouve aussi un numéro de PO ou d'OF.

Règles :
- Une palette qui tombe à 0 disparaît, l'article reste dans le catalogue.
- **Valider** enregistre tout ou rien : si une ligne est refusée, aucune n'est enregistrée.
- **Ajouter un item** (onglet Inventaire, sous la recherche) crée un nouvel article dans le catalogue, avec ses premières palettes si on les remplit.
- Toucher le numéro de palette (onglet Réceptions) permet de changer le numéro.
- Les champs « numéro de palette » commencent toujours par un P qu'on ne peut pas effacer ; seuls des chiffres peuvent suivre.
- La croix à droite de la recherche efface le texte. Entrée passe au champ de quantité suivant.
- **Verrouillage de l'application** : mot de passe `Appro` à l'ouverture ; l'application se verrouille seule après 2 h sans interaction, ou en touchant le grand logo Newrest au milieu de l'écran (affiché quand la liste est vide).
- Les mots de passe peuvent être changés avec les variables d'environnement `STOCK_APP_PASSWORD` (application) et `STOCK_PASSWORD` (inventaire).

## Lancer l'application

Première fois sur un PC : double-cliquer sur **`CREER_RACCOURCI.bat`**. Il crée sur le Bureau le raccourci **Warehouse DF** avec le logo de l'application ; on lance ensuite l'application avec ce raccourci.
(Un fichier `.bat` ne peut pas avoir son propre logo : c'est pour ça qu'on passe par un raccourci. Si le dossier de l'application est déplacé, relancer `CREER_RACCOURCI.bat`.)

Sans raccourci : 
Double-cliquer sur **`LANCER.bat`** (Python doit être installé, voir https://www.python.org/downloads/).

Ou, en ligne de commande, avec Python 3.9 ou plus récent (aucune dépendance à installer) :

```
python app.py
```

Le navigateur s'ouvre sur http://127.0.0.1:8765. La base `stock.db` est créée à côté de `app.py` (dossier parent) : c'est ce fichier qu'il faut sauvegarder.

Tests (depuis ce dossier) : `python -m unittest test_stock`

### Données de test

Double-cliquer sur **`CHARGER_DONNEES_TEST.bat`** (dans ce dossier) ajoute dans la base les articles de `donnees_test/stock_initial.tsv`
(une ligne par article, une colonne par palette P1…P48). Une palette contient au plus 100 pièces : une quantité supérieure
est remplacée par une valeur aléatoire entre 1 et 100. Les articles déjà présents ne sont pas modifiés, on peut donc le relancer sans risque.
Pour repartir de zéro : fermer l'application, supprimer `stock.db`, relancer le chargement.


### Plein écran

L'interface s'ouvre automatiquement en plein écran dans Chrome (ou Edge s'il n'y a pas Chrome), sans barre d'adresse ni onglets.
**Alt+F4** ferme l'interface ; fermer la fenêtre noire arrête l'application.
Pour une fenêtre de navigateur normale : `python app.py --fenetre`.

## Apparence

L'interface reprend la maquette `maquettes/maquette.pdf` : mêmes cotes, couleurs, polices (Open Sans, League Spartan) et logo Newrest.
L'écran est dessiné à l'échelle de la maquette puis agrandi pour occuper toute la largeur, quelle que soit la résolution.
Les polices sont fournies dans `static/fonts` : aucune connexion internet n'est nécessaire.
