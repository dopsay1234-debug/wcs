import os
import sys
import unittest

# stock.py est dans le dossier parent
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from stock import Stock, StockError


class StockTest(unittest.TestCase):
    def setUp(self):
        self.s = Stock(":memory:")
        self.a = self.s.create_article("AKASHI Whisky 70cl", [{"palette": "48", "qty": 28}])["id"]

    def types(self):
        return [h["type"] for h in reversed(self.s.history())]

    def test_create_normalises_palette_and_logs(self):
        self.assertEqual(self.s.article(self.a)["palettes"], [{"palette": "P48", "qty": 28}])
        self.assertEqual(self.types(), ["ajout_article", "reception"])

    def test_duplicate_name_refused(self):
        with self.assertRaises(StockError):
            self.s.create_article("akashi  whisky 70cl")

    def test_search(self):
        self.s.create_article("Chivas")
        self.assertEqual([r["name"] for r in self.s.search("aka")], ["AKASHI Whisky 70cl"])
        self.assertEqual(self.s.search("aka")[0]["total"], 28)
        self.assertEqual(self.s.search("%"), [])

    def test_reception_creates_palette(self):
        self.s.apply("RN", [{"article_id": self.a, "palette": "P48", "qty": 2}, {"article_id": self.a, "palette": "P50", "qty": 5}], "PO77", "2026-01-15")
        self.assertEqual(self.s.article(self.a)["palettes"], [{"palette": "P48", "qty": 30}, {"palette": "P50", "qty": 5}])

    def test_sortie_to_zero_removes_palette_but_keeps_article(self):
        self.s.apply("OF", [{"article_id": self.a, "palette": "P48", "qty": 28}], "OF123")
        self.assertEqual(self.s.article(self.a)["palettes"], [])
        self.assertEqual(self.types()[-2:], ["sortie", "palette_videe"])

    def test_sortie_above_stock_is_atomic(self):
        b = self.s.create_article("Chivas", [{"palette": "P1", "qty": 10}])["id"]
        with self.assertRaises(StockError):
            self.s.apply("OF", [{"article_id": b, "palette": "P1", "qty": 3}, {"article_id": self.a, "palette": "P48", "qty": 29}], "OF123")
        self.assertEqual(self.s.article(b)["palettes"], [{"palette": "P1", "qty": 10}])
        self.assertNotIn("sortie", self.types())

    def test_sortie_unknown_palette_refused(self):
        with self.assertRaises(StockError):
            self.s.apply("OF", [{"article_id": self.a, "palette": "P99", "qty": 1}], "OF123")

    def test_negative_or_empty_refused(self):
        with self.assertRaises(StockError):
            self.s.apply("RN", [{"article_id": self.a, "palette": "P48", "qty": -3}], "PO77", "2026-01-15")
        with self.assertRaises(StockError):
            self.s.apply("RN", [{"article_id": self.a, "palette": "P48", "qty": 0}], "PO77", "2026-01-15")

    def test_bare_p_refused(self):
        with self.assertRaises(StockError):
            self.s.apply("RN", [{"article_id": self.a, "palette": "P", "qty": 1}], "PO77", "2026-01-15")

    def test_rename_palette(self):
        self.s.rename_palette(self.a, "P48", "49")
        self.assertEqual(self.s.article(self.a)["palettes"], [{"palette": "P49", "qty": 28}])
        h = self.s.history()[0]
        self.assertEqual((h["type"], h["details"]), ("changement_palette", "P48 → P49"))

    def test_rename_onto_existing_refused(self):
        self.s.apply("RN", [{"article_id": self.a, "palette": "P50", "qty": 1}], "PO77", "2026-01-15")
        with self.assertRaises(StockError):
            self.s.rename_palette(self.a, "P48", "P50")

    def test_delete_keeps_readable_history(self):
        self.s.delete_article(self.a)
        self.assertEqual(self.s.search(""), [])
        h = self.s.history()[0]
        self.assertEqual((h["type"], h["article_name"], h["qty_before"]), ("suppression_article", "AKASHI Whisky 70cl", 28))
        with self.assertRaises(StockError):
            self.s.apply("RN", [{"article_id": self.a, "palette": "P48", "qty": 1}], "PO77", "2026-01-15")

    def test_inventory_grouped_by_pallet(self):
        b = self.s.create_article("Chivas", [{"palette": "P48", "qty": 5}, {"palette": "P2", "qty": 1}])["id"]
        inv = self.s.inventory()
        self.assertEqual([p["palette"] for p in inv], ["P2", "P48"])
        self.assertEqual(inv[1]["total"], 33)

    def test_set_quantity(self):
        self.s.set_quantity(self.a, "P48", 30)
        self.s.set_quantity(self.a, "P7", 4)
        self.assertEqual(self.s.article(self.a)["palettes"], [{"palette": "P48", "qty": 30}, {"palette": "P7", "qty": 4}])
        self.s.set_quantity(self.a, "P48", 0)
        self.assertEqual(self.s.article(self.a)["palettes"], [{"palette": "P7", "qty": 4}])
        self.assertEqual(self.types()[-3:], ["inventaire", "inventaire", "palette_videe"][-3:])

    def test_move(self):
        self.s.move(self.a, "P48", "P50", 8)
        self.assertEqual(self.s.article(self.a)["palettes"], [{"palette": "P48", "qty": 20}, {"palette": "P50", "qty": 8}])
        self.s.move(self.a, "P48", "P50", 20)
        self.assertEqual(self.s.article(self.a)["palettes"], [{"palette": "P50", "qty": 28}])
        with self.assertRaises(StockError):
            self.s.move(self.a, "P50", "P51", 29)

    def test_sortie_requires_of_number(self):
        with self.assertRaises(StockError):
            self.s.apply("OF", [{"article_id": self.a, "palette": "P48", "qty": 1}])
        with self.assertRaises(StockError):
            self.s.apply("OF", [{"article_id": self.a, "palette": "P48", "qty": 1}], "   ")

    def test_reception_requires_po_and_real_date(self):
        line = [{"article_id": self.a, "palette": "P48", "qty": 1}]
        with self.assertRaises(StockError):
            self.s.apply("RN", line, None, "2026-01-15")
        with self.assertRaises(StockError):
            self.s.apply("RN", line, "PO77", "")
        with self.assertRaises(StockError):
            self.s.apply("RN", line, "PO77", "2999-01-01")
        self.s.apply("RN", line, " po 77 ", "2026-01-15")
        h = self.s.history()[0]
        self.assertEqual((h["type"], h["ref"], h["doc_date"]), ("reception", "PO 77", "2026-01-15"))

    def test_one_validation_is_one_batch_with_its_of(self):
        b = self.s.create_article("Chivas", [{"palette": "P1", "qty": 10}])["id"]
        self.s.apply("OF", [{"article_id": self.a, "palette": "P48", "qty": 28}, {"article_id": b, "palette": "P1", "qty": 3}], " of 4521 ")
        rows = [h for h in self.s.history() if h["ref"]]
        self.assertEqual([h["type"] for h in reversed(rows)], ["sortie", "palette_videe", "sortie"])
        self.assertEqual({h["ref"] for h in rows}, {"OF 4521"})
        self.assertEqual(len({h["batch"] for h in rows}), 1)
        # la création de Chivas est un autre groupe, la recherche trouve l'OF
        self.assertNotIn(rows[0]["batch"], {h["batch"] for h in self.s.history() if not h["ref"]})
        self.assertEqual(len(self.s.history(query="4521")), 3)

    def test_old_database_gets_new_columns(self):
        import os
        import sqlite3
        import tempfile
        path = os.path.join(tempfile.mkdtemp(), "old.db")
        db = sqlite3.connect(path)
        db.executescript(
            "CREATE TABLE history (id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, type TEXT NOT NULL,"
            " article_name TEXT NOT NULL, palette TEXT, qty_before INTEGER, qty_after INTEGER, details TEXT);"
            "INSERT INTO history (ts, type, article_name) VALUES ('2026-01-01T10:00:00', 'ajout_article', 'Ancien');"
        )
        db.commit()
        db.close()
        s = Stock(path)
        s.create_article("Nouveau")
        self.assertEqual([(h["article_name"], h["batch"]) for h in s.history()], [("Nouveau", 1), ("Ancien", None)])
        s.close()


if __name__ == "__main__":
    unittest.main()
