"use strict";

// ---------- Outils ----------

const $ = (sel) => document.querySelector(sel);
const MOTION = !window.matchMedia("(prefers-reduced-motion: reduce)").matches;
const wait = (ms) => new Promise((r) => setTimeout(r, MOTION ? ms : 0));

function esc(text) {
  return String(text ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

const pieces = (n) => `${n} pièce${Math.abs(n) > 1 ? "s" : ""}`;

class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
}

async function api(method, url, body) {
  const headers = body ? { "Content-Type": "application/json" } : {};
  if (inv.token) headers["X-Token"] = inv.token;
  const res = await fetch(url, { method, headers, body: body ? JSON.stringify(body) : undefined });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(data.error || "Erreur de communication avec le serveur.", res.status);
  return data;
}

function normPalette(text) {
  let p = String(text || "").replace(/\s+/g, "").toUpperCase();
  if (/^\d+$/.test(p)) p = "P" + p;
  return p;
}

const hasPalette = (p) => /\d/.test(p || "");
const paletteSort = (a, b) => a.localeCompare(b, "fr", { numeric: true });

// Quantité tapée au clavier : nombre entier positif, vide = 0
const readQty = (input) => Math.max(0, Math.floor(Number(String(input.value).replace(/\D/g, "")) || 0));

// Relance une animation CSS déjà jouée sur l'élément
function replay(el, cls) {
  if (!el || !MOTION) return;
  el.classList.remove(cls);
  void el.offsetWidth;
  el.classList.add(cls);
}

function toast(text, kind = "ok") {
  const el = $("#toast");
  el.textContent = text;
  el.className = `toast ${kind}`;
  el.hidden = false;
  replay(el, "show");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(async () => {
    el.classList.add("hide");
    await wait(200);
    el.hidden = true;
  }, kind === "info" ? 3500 : 2600);
}

// ---------- Fenêtres ----------

function openModal(id) {
  const m = $(id);
  m.hidden = false;
  m.classList.remove("closing");
  replay(m, "opening");
}

async function closeModal(m) {
  if (m.hidden) return;
  if (m.id === "modal-doc") answerDoc(null);
  m.classList.add("closing");
  await wait(150);
  m.hidden = true;
  m.classList.remove("closing");
}

function closeModals() {
  document.querySelectorAll(".modal").forEach(closeModal);
}

function showError(message) {
  $("#error-text").textContent = message;
  openModal("#modal-error");
}

document.querySelectorAll(".modal").forEach((m) => {
  m.addEventListener("click", (e) => {
    if (e.target === m || e.target.closest("[data-close]")) closeModal(m);
  });
});

// ---------- Mise à l'échelle ----------
// L'écran est dessiné aux cotes de la maquette (1233 de large) puis agrandi
// pour occuper toute la largeur ; la hauteur suit celle de la fenêtre.

const DESIGN_WIDTH = 1233;
const stage = $("#stage");
let scale = 1;

function fit() {
  scale = window.innerWidth / DESIGN_WIDTH;
  stage.style.transform = `scale(${scale})`;
  stage.style.height = `${window.innerHeight / scale}px`;
}
window.addEventListener("resize", fit);
fit();

// Position d'un événement dans les coordonnées de la maquette
function stagePoint(e) {
  const r = stage.getBoundingClientRect();
  return { x: (e.clientX - r.left) / scale, y: (e.clientY - r.top) / scale };
}

const ICON_X_BLACK = `<svg viewBox="0 0 12 12"><path d="M1.5 1.5l9 9M10.5 1.5l-9 9" stroke="#000" stroke-width="2.8" stroke-linecap="square"/></svg>`;
const ICON_X_RED = `<svg class="ico-x-red" viewBox="0 0 19 19"><path d="M3 3l13 13M16 3L3 16" stroke="#ff3131" stroke-width="4.2" stroke-linecap="round"/></svg>`;
const ICON_PLUS_GREEN = `<svg class="ico-plus-green" viewBox="0 0 21 21"><path d="M10.5 2v17M2 10.5h17" stroke="#00bf63" stroke-width="4.4"/></svg>`;

// ---------- Effet d'appui sur les boutons ----------
// :active n'est pas fiable sur tous les écrans tactiles, on pose aussi une classe.

document.addEventListener("pointerdown", (e) => {
  const b = e.target.closest("button");
  if (b && !b.disabled) b.classList.add("pressed");
});
["pointerup", "pointercancel", "dragstart"].forEach((ev) =>
  document.addEventListener(ev, () => document.querySelectorAll("button.pressed").forEach((b) => b.classList.remove("pressed")))
);

// ---------- Barres de défilement ----------
// Discrètes au repos, elles s'allument pendant le défilement.

document.addEventListener(
  "scroll",
  (e) => {
    const el = e.target;
    if (!(el instanceof Element)) return;
    el.classList.add("scrolling");
    clearTimeout(el._scrollTimer);
    el._scrollTimer = setTimeout(() => el.classList.remove("scrolling"), 700);
  },
  true // l'événement « scroll » ne remonte pas, on l'écoute à la capture
);

// ---------- Champs « numéro de palette » ----------
// Toujours un P devant, impossible à effacer ; seuls des chiffres peuvent suivre.

function caretToEnd(input) {
  const n = input.value.length;
  input.setSelectionRange(n, n);
}

document.addEventListener(
  "input",
  (e) => {
    const input = e.target;
    if (!input.classList?.contains("pal-input")) return;
    input.value = "P" + input.value.replace(/\D/g, "");
    caretToEnd(input);
  },
  true // avant les autres écouteurs, qui lisent la valeur nettoyée
);

document.addEventListener("keydown", (e) => {
  const input = e.target;
  if (!input.classList?.contains("pal-input")) return;
  const atStart = input.selectionStart <= 1 && input.selectionEnd <= 1;
  if ((e.key === "Backspace" || e.key === "ArrowLeft") && atStart) e.preventDefault();
  if (e.key === "Home") {
    e.preventDefault();
    input.setSelectionRange(1, 1);
  }
});

["focusin", "click", "select"].forEach((ev) =>
  document.addEventListener(ev, (e) => {
    const input = e.target;
    if (!input.classList?.contains("pal-input")) return;
    if (!input.value.startsWith("P")) input.value = "P" + input.value.replace(/\D/g, "");
    requestAnimationFrame(() => {
      if (input.selectionStart < 1) input.setSelectionRange(Math.max(1, input.selectionEnd), Math.max(1, input.selectionEnd));
    });
  })
);

const paletteValue = (input) => (hasPalette(input.value) ? input.value : "");

// Champs de quantité : chiffres seulement
document.addEventListener(
  "input",
  (e) => {
    const input = e.target;
    if (!input.classList?.contains("qty-input")) return;
    const clean = input.value.replace(/\D/g, "").replace(/^0+(?=\d)/, "");
    if (clean !== input.value) input.value = clean;
  },
  true
);

// ---------- État ----------
// Chaque onglet a sa propre liste de travail.
// RN : { id, name, lines: [{ key, palette, stock, qty, isNew }] }
// OF : { id, name, pallets: [{ palette, stock }] (du moins rempli au plus rempli), palette, stock, qty }

// docs : pièce de la liste en cours, demandée au premier article
//   RN : { ref: numéro de PO, date: date réelle de réception (AAAA-MM-JJ) }   OF : { ref: numéro d'OF }
const state = { tab: "RN", lists: { RN: [], OF: [] }, docs: { RN: null, OF: null } };
let lineKey = 0;

const list = () => state.lists[state.tab];

function rnLinesFrom(article) {
  const lines = article.palettes
    .map((p) => ({ key: ++lineKey, palette: p.palette, stock: p.qty, qty: 0, isNew: false }))
    .sort((a, b) => paletteSort(a.palette, b.palette));
  if (!lines.length) lines.push({ key: ++lineKey, palette: "P", stock: 0, qty: 0, isNew: true });
  return lines;
}

function ofEntryFrom(article) {
  const pallets = article.palettes
    .map((p) => ({ palette: p.palette, stock: p.qty }))
    .sort((a, b) => a.stock - b.stock || paletteSort(a.palette, b.palette));
  const entry = { id: article.id, name: article.name, pallets, palette: null, stock: 0, qty: 0 };
  choosePallet(entry, 0);
  return entry;
}

// Sortie : on prend la palette la moins remplie qui peut fournir la quantité voulue.
// Renvoie un message quand la palette affichée change à cause de la quantité.
function choosePallet(entry, want) {
  const before = entry.palette;
  const beforeStock = entry.stock;
  if (!entry.pallets.length) {
    Object.assign(entry, { palette: null, stock: 0, qty: 0 });
    return null;
  }
  want = Math.max(0, want);
  let chosen = entry.pallets.find((p) => p.stock >= want);
  let note = null;
  if (!chosen) {
    chosen = entry.pallets[entry.pallets.length - 1];
    want = chosen.stock;
    note = `Maximum ${pieces(want)} sur une même palette (${chosen.palette}).`;
  }
  Object.assign(entry, { palette: chosen.palette, stock: chosen.stock, qty: want });
  if (!note && before && chosen.palette !== before && want > beforeStock) {
    note = `${before} : il ne reste que ${pieces(beforeStock)} → palette ${chosen.palette} proposée.`;
  }
  return note;
}

async function addToWorklist(id) {
  if (list().some((e) => e.id === id)) return toast("Déjà dans la liste.", "info");
  // Premier article d'une réception ou d'une sortie : on demande d'abord le PO ou l'OF
  const tab = state.tab;
  if (!list().length && !state.docs[tab]) {
    const doc = await askDoc(tab);
    if (!doc) return;
    state.docs[tab] = doc;
  }
  const article = await api("GET", `/api/articles/${id}`);
  list().push(state.tab === "RN" ? { id: article.id, name: article.name, lines: rnLinesFrom(article) } : ofEntryFrom(article));
  render();
  // Le curseur va directement dans le premier champ de quantité du nouvel article
  const card = cards.querySelector(`[data-id="${article.id}"]`);
  card?.querySelector(".palette-input, .qty-input")?.focus();
}

// Recharge le stock des articles de la liste (changement d'onglet, refus, renommage)
// en gardant les quantités déjà saisies.
async function reload(tab) {
  const fresh = [];
  for (const old of state.lists[tab]) {
    let article;
    try {
      article = await api("GET", `/api/articles/${old.id}`);
    } catch {
      continue; // article supprimé entre-temps
    }
    if (tab === "OF") {
      const entry = ofEntryFrom(article);
      choosePallet(entry, old.qty);
      fresh.push(entry);
      continue;
    }
    const entry = { id: article.id, name: article.name, lines: rnLinesFrom(article) };
    for (const l of entry.lines) {
      const o = old.lines.find((x) => !x.isNew && x.palette === l.palette);
      if (o) l.qty = o.qty;
    }
    const extra = old.lines.filter((x) => x.isNew && (hasPalette(x.palette) || x.qty));
    if (extra.length) entry.lines = entry.lines.filter((l) => !(l.isNew && !hasPalette(l.palette))).concat(extra);
    fresh.push(entry);
  }
  state.lists[tab] = fresh;
}

// ---------- Onglets ----------

const SECTIONS = { RN: "#work", OF: "#work", INV: "#inv", HIST: "#hist" };
let previousTab = "RN";

document.querySelectorAll(".tab").forEach((btn) => {
  btn.addEventListener("click", async () => {
    if (state.tab === btn.dataset.tab) return;
    if (btn.dataset.tab === "INV") previousTab = state.tab;
    state.tab = btn.dataset.tab;
    document.querySelectorAll(".tab").forEach((b) => b.classList.toggle("active", b === btn));
    // la forme orange passe sous le nouvel onglet
    document.querySelectorAll(".tab-rise").forEach((r) => r.classList.toggle("up", r.dataset.for === btn.dataset.tab));
    stage.className = `tab-${state.tab}`;
    for (const sel of new Set(Object.values(SECTIONS))) $(sel).hidden = sel !== SECTIONS[state.tab];
    clearSearch();
    if (state.tab === "HIST") return loadHistory();
    if (state.tab === "INV") return showInventory();
    await reload(state.tab); // le stock a pu changer dans l'autre onglet
    render();
  });
});

// ---------- Recherche ----------

const searchInput = $("#search");
const searchPanel = searchInput.closest(".search-panel");
const suggestions = $("#suggestions");
let searchSeq = 0;

function hideSuggestions() {
  suggestions.hidden = true;
  searchPanel.classList.remove("open");
}

function clearSearch() {
  searchInput.value = "";
  searchPanel.classList.remove("has-text");
  hideSuggestions();
}

async function runSearch() {
  const q = searchInput.value.trim();
  if (!q) return hideSuggestions();
  const seq = ++searchSeq;
  const results = await api("GET", `/api/articles?q=${encodeURIComponent(q)}`);
  if (seq !== searchSeq) return; // une frappe plus récente a déjà répondu
  // Ordre alphabétique français (É rangé avec E)
  results.sort((a, b) => a.name.localeCompare(b.name, "fr", { sensitivity: "base" }));
  suggestions.innerHTML = results.length
    ? results.map((a) => `<li data-id="${a.id}">${esc(a.name)}</li>`).join("")
    : `<li class="none">Aucun article trouvé</li>`;
  if (suggestions.hidden) {
    suggestions.hidden = false;
    replay(suggestions, "drop");
  }
  searchPanel.classList.add("open");
}

searchInput.addEventListener("input", () => {
  searchPanel.classList.toggle("has-text", searchInput.value !== "");
  clearTimeout(runSearch.timer);
  runSearch.timer = setTimeout(() => runSearch().catch((e) => showError(e.message)), 120);
});
searchInput.addEventListener("focus", () => searchInput.value.trim() && runSearch().catch(() => {}));
searchInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    const first = suggestions.querySelector("li[data-id]");
    if (first && !suggestions.hidden) first.click();
  } else if (e.key === "Escape") hideSuggestions();
});

suggestions.addEventListener("click", async (e) => {
  const li = e.target.closest("li[data-id]");
  if (!li) return;
  clearSearch();
  try {
    await addToWorklist(Number(li.dataset.id));
  } catch (err) {
    showError(err.message);
  }
});

document.addEventListener("pointerdown", (e) => {
  if (!e.target.closest(".search-panel")) hideSuggestions();
});

$("#search-x").innerHTML = ICON_X_BLACK;
$("#search-x").addEventListener("click", () => {
  clearSearch();
  searchInput.focus();
});

// ---------- Animations d'entrée ----------
// Seuls les éléments qui n'étaient pas affichés au rendu précédent sont animés.

const shown = { list: new Set(), cards: new Set(), inv: new Set() };

function enter(kind, key, next) {
  next.add(key);
  return MOTION && !shown[kind].has(key) ? "enter" : "";
}

// ---------- Liste de travail (colonne gauche) ----------

const worklist = $("#worklist");

function renderWorklist() {
  const next = new Set();
  worklist.innerHTML = list()
    .map(
      (e) => `<li data-id="${e.id}" class="${enter("list", `${state.tab}-${e.id}`, next)}">
        <div class="row">${esc(e.name)}<button class="x" aria-label="Retirer">${ICON_X_BLACK}</button></div>
      </li>`
    )
    .join("");
  shown.list = next;
  $("#worklist-empty").hidden = list().length > 0;
  $(".list-panel").classList.toggle("empty", list().length === 0);
  $("#clear-all").hidden = list().length === 0;
}

// Fait disparaître en douceur les éléments de la liste et les cartes d'un article
async function animateOut(ids) {
  if (!MOTION) return;
  for (const id of ids) {
    worklist.querySelector(`li[data-id="${id}"]`)?.classList.add("leave");
    cards.querySelectorAll(`[data-id="${id}"]`).forEach((c) => c.classList.add("leave"));
  }
  await wait(180);
}

worklist.addEventListener("click", async (e) => {
  const li = e.target.closest("li");
  if (!li || !e.target.closest(".x")) return;
  const id = Number(li.dataset.id);
  const tab = state.tab;
  await animateOut([id]);
  state.lists[tab] = state.lists[tab].filter((x) => x.id !== id);
  render();
});

$("#clear-all").addEventListener("click", async () => {
  const tab = state.tab;
  await animateOut(list().map((e) => e.id));
  state.lists[tab] = [];
  render();
});

// ---------- Cartes (zone droite) ----------

const cards = $("#cards");
const long = (text) => String(text).length > 3;
const qtyValue = (q) => (q ? String(q) : "");

// Barre au-dessus des cartes : numéro de PO / OF (et date de réception), à toucher pour modifier
function docBarHtml(tab) {
  const doc = state.docs[tab];
  if (!list().length) return "";
  const label = tab === "RN" ? "N° de PO" : "N° d'OF";
  const when = tab === "RN" && doc?.date ? ` · reçue le ${fmtDay(doc.date)}` : "";
  return `<div class="doc-bar">${label} <button class="doc-ref">${esc(doc?.ref || "—")}${when ? `<b>${esc(when)}</b>` : ""}</button><small>toucher pour modifier</small></div>`;
}

function renderRN(next) {
  cards.className = "cards rn";
  cards.innerHTML = docBarHtml("RN") + list()
    .map(
      (e, i) => `<div class="rn-card ${enter("cards", `rn-${e.id}`, next)}" data-i="${i}" data-id="${e.id}">
        <div class="name"><span>${esc(e.name)}</span></div>
        <div class="pal-col">
          <span class="cap">Palette</span>
          ${e.lines
            .map((l, j) => {
              const anim = enter("cards", `line-${l.key}`, next);
              return l.isNew
                ? `<input class="pal-badge pal-input palette-input ${anim}" data-j="${j}" type="text" inputmode="numeric" value="${esc(l.palette || "P")}">`
                : `<button class="pal-badge rename ${long(l.palette) ? "long" : ""} ${anim}" data-j="${j}">${esc(l.palette)}</button>`;
            })
            .join("")}
          <button class="add-pal add-line" aria-label="Ajouter une palette">${ICON_PLUS_GREEN}</button>
        </div>
        <div class="divider"></div>
        <div class="lines">
          <div class="rn-caps"><span>Stock actuel</span><span>À ajouter</span><span>Après</span><span></span></div>
          ${e.lines
            .map(
              (l, j) => `<div class="rn-line ${shown.cards.has(`line-${l.key}`) || !MOTION ? "" : "enter"}" data-j="${j}">
                <span class="stock-badge ${long(l.stock) ? "long" : ""}">${l.stock}</span>
                <input class="qty-input ${l.qty ? "on" : ""}" type="text" inputmode="numeric" placeholder="0" value="${qtyValue(l.qty)}">
                <span class="after ${l.qty ? "on" : ""}">${l.stock + l.qty}</span>
                <button class="x-btn remove-line" aria-label="Retirer la ligne">${ICON_X_RED}</button>
              </div>`
            )
            .join("")}
        </div>
      </div>`
    )
    .join("");
}

function renderOF(next) {
  cards.className = "cards of";
  cards.innerHTML =
    (list().length
      ? `<div class="of-head">
          ${docBarHtml("OF")}
          <div class="of-caps"><span>Article</span><span>Palette</span><span>Stock actuel</span><span>À retirer</span><span>Restant</span></div>
        </div>`
      : "") +
    list()
      .map((e, i) => {
        const anim = enter("cards", `of-${e.id}`, next);
        return e.palette
          ? `<div class="of-card ${anim}" data-i="${i}" data-id="${e.id}">
              <div class="name">${esc(e.name)}</div>
              <span class="pal ${long(e.palette) ? "long" : ""}">${esc(e.palette)}</span>
              <span class="stock-badge ${long(e.stock) ? "long" : ""}">${e.stock}</span>
              <input class="qty-input ${e.qty ? "on" : ""}" type="text" inputmode="numeric" placeholder="0" value="${qtyValue(e.qty)}">
              <span class="after ${e.qty ? "on" : ""}">${e.stock - e.qty}</span>
            </div>`
          : `<div class="of-card ${anim}" data-i="${i}" data-id="${e.id}"><div class="name">${esc(e.name)}</div><span class="none">Aucune palette en stock</span></div>`;
      })
      .join("");
}

function render() {
  // Liste vide : la prochaine réception / sortie redemandera son PO / OF
  for (const tab of ["RN", "OF"]) if (!state.lists[tab].length) state.docs[tab] = null;
  renderWorklist();
  const next = new Set();
  if (state.tab === "RN") renderRN(next);
  else if (state.tab === "OF") renderOF(next);
  shown.cards = next;
  const empty = list().length === 0;
  const panel = $("#work .right-panel");
  if (panel.classList.contains("empty") !== empty) {
    panel.classList.toggle("empty", empty);
    replay(empty ? $("#empty") : $("#right-scroll"), "fade-in");
  }
  $("#empty").hidden = !empty;
}

function lineAt(el) {
  const card = el.closest("[data-i]");
  const line = el.closest("[data-j]");
  if (!card || !line) return null;
  return list()[Number(card.dataset.i)].lines[Number(line.dataset.j)];
}

// Réception : pièces à ajouter sur une ligne
function onRnQty(input) {
  const line = lineAt(input);
  line.qty = readQty(input);
  const after = input.closest(".rn-line").querySelector(".after");
  after.textContent = line.stock + line.qty;
  after.classList.toggle("on", line.qty > 0);
  input.classList.toggle("on", line.qty > 0);
}

// Sortie : pièces à retirer ; la palette suit la quantité demandée
function onOfQty(input) {
  const card = input.closest("[data-i]");
  const entry = list()[Number(card.dataset.i)];
  const before = entry.palette;
  const want = readQty(input);
  const note = choosePallet(entry, want);
  if (entry.qty !== want) input.value = qtyValue(entry.qty); // plafonné au stock
  input.classList.toggle("on", entry.qty > 0);
  const after = card.querySelector(".after");
  after.textContent = entry.stock - entry.qty;
  after.classList.toggle("on", entry.qty > 0);
  if (entry.palette !== before) {
    const pal = card.querySelector(".pal");
    const badge = card.querySelector(".stock-badge");
    pal.textContent = entry.palette;
    pal.classList.toggle("long", long(entry.palette));
    badge.textContent = entry.stock;
    badge.classList.toggle("long", long(entry.stock));
    replay(pal, "flash");
    replay(badge, "flash");
  }
  if (note) toast(note, "info");
}

cards.addEventListener("input", (e) => {
  const t = e.target;
  if (t.classList.contains("palette-input")) lineAt(t).palette = t.value;
  else if (t.classList.contains("qty-input")) state.tab === "OF" ? onOfQty(t) : onRnQty(t);
});

// Un même article ne peut pas avoir deux fois la même palette
cards.addEventListener("change", (e) => {
  const t = e.target;
  if (!t.classList.contains("palette-input") || !hasPalette(t.value)) return;
  const entry = list()[Number(t.closest("[data-i]").dataset.i)];
  const line = lineAt(t);
  const p = normPalette(t.value);
  if (entry.lines.some((l) => l !== line && normPalette(l.palette) === p)) {
    toast(`${p} existe déjà pour cet article.`, "info");
    t.value = "P";
    line.palette = "P";
    replay(t, "shake");
    t.focus();
  }
});

cards.addEventListener("focusin", (e) => {
  if (e.target.classList.contains("qty-input")) e.target.select();
});

// Entrée : passe au champ suivant
cards.addEventListener("keydown", (e) => {
  if (e.key !== "Enter" || e.target.tagName !== "INPUT") return;
  e.preventDefault();
  const fields = [...cards.querySelectorAll("input")];
  const next = fields[fields.indexOf(e.target) + 1];
  if (next) next.focus();
  else e.target.blur();
});

cards.addEventListener("click", async (e) => {
  if (e.target.closest(".doc-ref")) {
    const tab = state.tab;
    const doc = await askDoc(tab, state.docs[tab]);
    if (doc) {
      state.docs[tab] = doc;
      render();
    }
    return;
  }
  const card = e.target.closest("[data-i]");
  if (!card || state.tab !== "RN") return;
  const entry = list()[Number(card.dataset.i)];
  if (e.target.closest(".add-line")) {
    entry.lines.push({ key: ++lineKey, palette: "P", stock: 0, qty: 0, isNew: true });
    render();
    const inputs = cards.querySelectorAll(`[data-i="${card.dataset.i}"] .palette-input`);
    inputs[inputs.length - 1]?.focus();
  } else if (e.target.closest(".remove-line")) {
    const j = Number(e.target.closest("[data-j]").dataset.j);
    if (MOTION) {
      card.querySelectorAll(`[data-j="${j}"]`).forEach((el) => el.classList.add("leave"));
      await wait(160);
    }
    entry.lines.splice(j, 1);
    render();
  } else if (e.target.closest(".rename")) {
    askRenamePalette(entry, lineAt(e.target));
  }
});

// ---------- Validation ----------

function pendingLines() {
  const lines = [];
  for (const e of list()) {
    if (state.tab === "OF") {
      if (e.qty > 0) lines.push({ article_id: e.id, palette: e.palette, qty: e.qty, name: e.name });
    } else {
      for (const l of e.lines) if (l.qty > 0) lines.push({ article_id: e.id, palette: l.palette, qty: l.qty, name: e.name });
    }
  }
  return lines;
}

$("#validate").addEventListener("click", async () => {
  const tab = state.tab;
  const lines = pendingLines();
  if (!lines.length) {
    if (tab === "OF") return toast("Aucune quantité à retirer.", "info");
    // Réception sans quantité : on valide simplement la liste
    if (!list().length) return;
    await animateOut(list().map((e) => e.id));
    state.lists.RN = [];
    render();
    return toast("Réception validée, aucune quantité modifiée.");
  }
  const missing = lines.find((l) => !hasPalette(l.palette));
  if (missing) return showError(`${missing.name} : indiquez le numéro de palette.`);
  // Deux lignes du même article sur la même palette : on refuse pour éviter une double saisie
  const seen = new Set();
  for (const l of lines) {
    const k = `${l.article_id}|${normPalette(l.palette)}`;
    if (seen.has(k)) return showError(`${l.name} : la palette ${normPalette(l.palette)} apparaît deux fois.`);
    seen.add(k);
  }
  if (!state.docs[tab]) {
    const doc = await askDoc(tab);
    if (!doc) return;
    state.docs[tab] = doc;
  }
  const { ref, date } = state.docs[tab];
  const button = $("#validate");
  button.disabled = true;
  try {
    await api("POST", "/api/movements", { kind: tab, lines: lines.map(({ name, ...l }) => l), ref, date });
    const total = lines.reduce((s, l) => s + l.qty, 0);
    await animateOut(state.lists[tab].map((e) => e.id));
    state.lists[tab] = [];
    render();
    toast(tab === "RN" ? `Réception enregistrée (PO ${ref}) : ${pieces(total)}.` : `Sortie enregistrée (OF ${ref}) : ${pieces(total)}.`);
  } catch (err) {
    showError(err.message + "\n\nRien n'a été enregistré.");
    await reload(tab);
    render();
  }
  button.disabled = false;
});

// ---------- Fenêtre « Ajouter un item » ----------

const itemLines = $("#item-lines");

function addItemLine() {
  const div = document.createElement("div");
  div.className = "item-line" + (MOTION && itemLines.children.length ? " enter" : "");
  div.innerHTML = `<input class="pal-field pal-input ip" type="text" inputmode="numeric" value="P" autocomplete="off">
    <input class="qty-field qty-input iq" type="text" inputmode="numeric" placeholder="...." autocomplete="off">
    ${itemLines.children.length ? `<button class="rm" aria-label="Retirer">${ICON_X_BLACK}</button>` : ""}`;
  itemLines.appendChild(div);
}

// Le bouton est dans l'onglet Inventaire : le nom est prérempli avec sa recherche
$("#new-item").addEventListener("click", () => {
  $("#item-name").value = invSearch.value.trim();
  $("#item-error").textContent = "";
  itemLines.innerHTML = "";
  addItemLine();
  openModal("#modal-item");
  $("#item-name").focus();
});

$("#item-add-line").innerHTML = ICON_PLUS_GREEN;
$("#item-add-line").addEventListener("click", () => {
  addItemLine();
  itemLines.lastElementChild.querySelector("input").focus();
});

itemLines.addEventListener("click", (e) => {
  if (e.target.closest(".rm")) e.target.closest(".item-line").remove();
});

$("#item-save").addEventListener("click", async () => {
  const palettes = [...itemLines.querySelectorAll(".item-line")].map((row) => ({
    palette: paletteValue(row.querySelector(".ip")),
    qty: row.querySelector(".iq").value.trim(),
  }));
  const used = palettes.filter((p) => p.palette).map((p) => normPalette(p.palette));
  const dup = used.find((p, i) => used.indexOf(p) !== i);
  if (dup) {
    $("#item-error").textContent = `La palette ${dup} est indiquée deux fois.`;
    return replay($("#item-error"), "shake");
  }
  try {
    const article = await api("POST", "/api/articles", { name: $("#item-name").value, palettes });
    closeModals();
    toast(`« ${article.name} » ajouté au catalogue.`);
    await refreshInventory();
  } catch (err) {
    $("#item-error").textContent = err.message;
    replay($("#item-error"), "shake");
  }
});

// ---------- Numéro de PO / d'OF ----------
// askDoc(tab) ouvre la fenêtre et renvoie { ref, date } (réception) ou { ref } (sortie), ou null si on annule.

let docResolve = null;
let docTab = "RN";

const todayIso = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};
// La date en toutes lettres, pour lever le doute jour / mois quel que soit le réglage de Windows
function showDocDate() {
  const v = $("#doc-date").value;
  const d = v ? new Date(`${v}T12:00:00`) : null;
  $("#doc-date-text").textContent = d && !isNaN(d) ? d.toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long", year: "numeric" }) : "";
}
const fmtDay = (iso) => (/^\d{4}-\d{2}-\d{2}$/.test(iso || "") ? iso.split("-").reverse().join("/") : iso || "");

function askDoc(tab, current = null) {
  answerDoc(null);
  docTab = tab;
  const rn = tab === "RN";
  $("#doc-title").textContent = rn ? "Réception" : "Numéro d'OF";
  $("#doc-text").textContent = rn ? "Indiquez le numéro de PO et la date réelle de la réception." : "Indiquez le numéro de l'OF de cette sortie.";
  $("#doc-ref-label").textContent = rn ? "N° de PO" : "N° d'OF";
  $("#doc-ref").placeholder = rn ? "N° de PO" : "N° d'OF";
  $("#doc-ref").value = current?.ref || "";
  $("#doc-date-wrap").hidden = !rn;
  $("#doc-date").max = todayIso();
  $("#doc-date").value = current?.date || todayIso();
  showDocDate();
  $("#doc-error").textContent = "";
  openModal("#modal-doc");
  setTimeout(() => $("#doc-ref").select(), 60);
  return new Promise((resolve) => (docResolve = resolve));
}

function answerDoc(value) {
  const resolve = docResolve;
  docResolve = null;
  resolve?.(value);
}

function docFail(message) {
  $("#doc-error").textContent = message;
  replay($("#doc-error"), "shake");
}

function saveDoc() {
  const rn = docTab === "RN";
  // « PO 1234 », « po1234 » et « 1234 » donnent tous « 1234 » (de même pour OF)
  const ref = $("#doc-ref").value.trim().toUpperCase().replace(rn ? /^PO\s*/ : /^OF\s*/, "").replace(/\s+/g, " ");
  if (!ref) return docFail(rn ? "Indiquez le numéro de PO." : "Indiquez le numéro d'OF.");
  const doc = { ref };
  if (rn) {
    doc.date = $("#doc-date").value;
    if (!doc.date) return docFail("Indiquez la date de réception.");
    if (doc.date > todayIso()) return docFail("La date de réception ne peut pas être dans le futur.");
  }
  answerDoc(doc);
  closeModal($("#modal-doc"));
}

$("#doc-save").addEventListener("click", saveDoc);
$("#doc-ref").addEventListener("keydown", (e) => {
  if (e.key !== "Enter") return;
  if (docTab === "RN") $("#doc-date").focus();
  else saveDoc();
});
$("#doc-date").addEventListener("keydown", (e) => e.key === "Enter" && saveDoc());
$("#doc-date").addEventListener("input", showDocDate);

// ---------- Changement de numéro de palette ----------

let renameTarget = null;

function askRenamePalette(entry, line) {
  renameTarget = { entry, line };
  $("#palette-text").textContent = `${entry.name} — palette actuelle : ${line.palette} (${pieces(line.stock)})`;
  $("#palette-new").value = "P";
  $("#palette-error").textContent = "";
  openModal("#modal-palette");
  $("#palette-new").focus();
}

$("#palette-save").addEventListener("click", async () => {
  const { entry, line } = renameTarget;
  const newName = paletteValue($("#palette-new"));
  try {
    await api("PUT", `/api/articles/${entry.id}/palettes`, { old: line.palette, new: newName });
    closeModals();
    const oldName = line.palette;
    line.palette = normPalette(newName); // même normalisation que le serveur
    await reload("RN");
    render();
    toast(`Palette ${oldName} renommée en ${line.palette}.`);
  } catch (err) {
    $("#palette-error").textContent = err.message;
    replay($("#palette-error"), "shake");
  }
});

["#palette-new", "#item-name"].forEach((sel) =>
  $(sel).addEventListener("keydown", (e) => {
    if (e.key === "Enter") (sel === "#palette-new" ? $("#palette-save") : $("#item-save")).click();
  })
);

// ---------- Inventaire ----------
// Protégé par mot de passe ; la session dure une heure ou jusqu'au cadenas.

const inv = { token: null, expiresAt: 0, pallets: [], articles: [], selected: null };
const invGrid = $("#inv-grid");
const invList = $("#inv-articles");
const invSearch = $("#inv-search");

function showInventory() {
  const open = Boolean(inv.token) && Date.now() < inv.expiresAt;
  if (!open && inv.token) lockInventory(false);
  $("#inv-locked").hidden = open; // voile transparent par-dessus l'inventaire vide
  if (open) {
    updateTimer();
    refreshInventory();
  } else {
    $("#inv-password").value = "";
    $("#inv-password-error").textContent = "";
    setTimeout(() => $("#inv-password").focus(), 50);
  }
}

async function unlockInventory() {
  try {
    const res = await api("POST", "/api/unlock", { password: $("#inv-password").value });
    inv.token = res.token;
    inv.expiresAt = Date.now() + res.expires_in * 1000;
    showInventory();
  } catch (err) {
    $("#inv-password-error").textContent = err.message;
    replay($("#inv-password-error"), "shake");
    $("#inv-password").select();
  }
}

function lockInventory(notify = true) {
  if (inv.token) api("POST", "/api/lock").catch(() => {});
  inv.token = null;
  inv.expiresAt = 0;
  // Rien ne reste visible sous le voile une fois verrouillé
  Object.assign(inv, { pallets: [], articles: [], selected: null });
  renderInvList();
  renderInvGrid();
  $("#inv-timer").textContent = "";
  closeModal($("#modal-inv"));
  if (state.tab === "INV") showInventory();
  if (notify) toast("Inventaire verrouillé.", "info");
}

function updateTimer() {
  const min = Math.max(0, Math.ceil((inv.expiresAt - Date.now()) / 60000));
  $("#inv-timer").textContent = `· ${min} min`;
}

// Verrouillage automatique au bout d'une heure
setInterval(() => {
  if (!inv.token) return;
  if (Date.now() >= inv.expiresAt) lockInventory();
  else updateTimer();
}, 15000);

$("#inv-unlock").addEventListener("click", unlockInventory);
$("#inv-password").addEventListener("keydown", (e) => e.key === "Enter" && unlockInventory());
// Cadenas : on verrouille et on revient sur Réceptions
$("#inv-lock").addEventListener("click", () => {
  lockInventory();
  document.querySelector('.tab[data-tab="RN"]').click();
});
// « Retour » : on quitte l'inventaire sans le déverrouiller
$("#inv-back").addEventListener("click", () => document.querySelector(`.tab[data-tab="${previousTab}"]`).click());

// Appel protégé : une session expirée renvoie à l'écran du mot de passe
async function invApi(method, url, body) {
  try {
    return await api(method, url, body);
  } catch (err) {
    if (err.status === 401) {
      lockInventory(false);
      toast(err.message, "info");
    }
    throw err;
  }
}

async function refreshInventory() {
  try {
    const [pallets, articles] = await Promise.all([invApi("GET", "/api/inventory"), api("GET", "/api/articles?all=1")]);
    inv.pallets = pallets;
    inv.articles = articles.sort((a, b) => a.name.localeCompare(b.name, "fr", { sensitivity: "base" }));
    if (inv.selected && !inv.articles.some((a) => a.id === inv.selected)) inv.selected = null;
    renderInvList();
    renderInvGrid();
  } catch (err) {
    if (err.status !== 401) showError(err.message);
  }
}

function renderInvList() {
  const q = invSearch.value.trim().toLowerCase();
  const items = inv.articles.filter((a) => !q || a.name.toLowerCase().includes(q));
  invList.innerHTML = items.length
    ? items
        .map(
          (a) => `<li data-id="${a.id}" class="${a.id === inv.selected ? "sel" : ""}">
            <button class="delete-zone"><span>SUPPRIMER</span></button>
            <div class="row">${esc(a.name)}<span class="tot">${pieces(a.total)} · ${a.palettes} palette${a.palettes > 1 ? "s" : ""}</span>
              <span class="grip" data-drag='${esc(JSON.stringify({ article_id: a.id, name: a.name }))}'>⠿</span></div>
          </li>`
        )
        .join("")
    : `<li class="none-found">Aucun article</li>`;
}

function renderInvGrid() {
  const next = new Set();
  const sel = inv.selected;
  invGrid.classList.toggle("filtered", sel != null);
  // « Nouvelle palette » en premier : toujours à portée de doigt pendant un glisser-déposer
  invGrid.innerHTML =
    `<div class="new-pal-card" data-new-palette>${ICON_PLUS_GREEN}Nouvelle palette<br><small>glissez un article ici</small></div>` +
    inv.pallets
      .map((p) => {
        const match = sel != null && p.items.some((it) => it.article_id === sel);
        return `<div class="pal-card ${match ? "match" : ""} ${enter("inv", p.palette, next)}" data-palette="${esc(p.palette)}">
          <div class="pal-card-head"><span class="pal-badge">${esc(p.palette)}</span><span class="tot">${pieces(p.total)}</span></div>
          ${p.items
            .map(
              (it) => `<div class="inv-item ${it.article_id === sel ? "sel" : ""}">
                <span class="grip" data-drag='${esc(JSON.stringify({ article_id: it.article_id, name: it.name, palette: p.palette, qty: it.qty }))}'>⠿</span>
                <span class="nm">${esc(it.name)}</span>
                <button class="q" data-edit='${esc(JSON.stringify({ article_id: it.article_id, name: it.name, palette: p.palette, qty: it.qty }))}'>${it.qty}</button>
              </div>`
            )
            .join("")}
        </div>`;
      })
      .join("");
  shown.inv = next;
}

invSearch.addEventListener("input", () => {
  invSearch.closest(".search-panel").classList.toggle("has-text", invSearch.value !== "");
  renderInvList();
});
$("#inv-search-x").innerHTML = ICON_X_BLACK;
$("#inv-search-x").addEventListener("click", () => {
  invSearch.value = "";
  invSearch.closest(".search-panel").classList.remove("has-text");
  renderInvList();
  invSearch.focus();
});

// Toucher un article : ses palettes ressortent dans la grille
invList.addEventListener("click", (e) => {
  const li = e.target.closest("li[data-id]");
  if (!li) return;
  if (e.target.closest(".delete-zone")) return askDeleteArticle(Number(li.dataset.id));
  if (e.target.closest(".grip")) return;
  const id = Number(li.dataset.id);
  inv.selected = inv.selected === id ? null : id;
  renderInvList();
  renderInvGrid();
  invGrid.querySelector(".pal-card.match")?.scrollIntoView({ behavior: MOTION ? "smooth" : "auto", block: "nearest" });
});

// Toucher une quantité : correction
invGrid.addEventListener("click", (e) => {
  const q = e.target.closest("[data-edit]");
  if (q) return openInvDialog("edit", JSON.parse(q.dataset.edit));
  if (e.target.closest("[data-new-palette]")) toast("Glissez un article (⠿) sur « Nouvelle palette » pour le placer sur une nouvelle palette.", "info");
});

// ----- Glisser-déposer (souris et doigt) -----

let drag = null;

document.addEventListener("pointerdown", (e) => {
  const grip = e.target.closest("[data-drag]");
  if (!grip || state.tab !== "INV") return;
  e.preventDefault();
  const src = JSON.parse(grip.dataset.drag);
  const ghost = document.createElement("div");
  ghost.className = "drag-ghost";
  ghost.textContent = src.palette ? `${src.name} · ${pieces(src.qty)} (${src.palette})` : src.name;
  stage.appendChild(ghost);
  drag = { src, ghost, over: null };
  grip.setPointerCapture(e.pointerId);
  document.body.classList.add("dragging");
  moveGhost(e);
});

function moveGhost(e) {
  const p = stagePoint(e);
  drag.ghost.style.left = `${p.x}px`;
  drag.ghost.style.top = `${p.y}px`;
  const el = document.elementFromPoint(e.clientX, e.clientY);
  const target = el?.closest(".pal-card, .new-pal-card") || null;
  if (target !== drag.over) {
    drag.over?.classList.remove("drop-over");
    target?.classList.add("drop-over");
    drag.over = target;
  }
  // Défilement automatique près des bords de la grille
  const r = invGrid.getBoundingClientRect();
  if (e.clientY > r.bottom - 30 * scale) invGrid.scrollTop += 12;
  else if (e.clientY < r.top + 30 * scale && e.clientY > r.top - 40 * scale) invGrid.scrollTop -= 12;
}

document.addEventListener("pointermove", (e) => drag && moveGhost(e));

function endDrag(drop) {
  if (!drag) return;
  const { src, ghost, over } = drag;
  drag = null;
  ghost.remove();
  over?.classList.remove("drop-over");
  document.body.classList.remove("dragging");
  if (!drop || !over) return;
  if (over.hasAttribute("data-new-palette")) return openInvDialog(src.palette ? "move-new" : "add-new", src);
  const target = over.dataset.palette;
  if (src.palette === target) return;
  openInvDialog(src.palette ? "move" : "add", { ...src, target });
}

document.addEventListener("pointerup", () => endDrag(true));
document.addEventListener("pointercancel", () => endDrag(false));

// ----- Fenêtre d'inventaire : ajout, déplacement, correction -----

let invAction = null;

function qtyOn(article_id, palette) {
  const p = inv.pallets.find((x) => x.palette === palette);
  return p?.items.find((it) => it.article_id === article_id)?.qty || 0;
}

function openInvDialog(mode, data) {
  invAction = { mode, ...data };
  const needPal = mode === "add-new" || mode === "move-new";
  const titles = {
    add: `Ajouter sur ${data.target}`,
    "add-new": "Ajouter sur une nouvelle palette",
    move: `Déplacer vers ${data.target}`,
    "move-new": "Déplacer vers une autre palette",
    edit: `Corriger la quantité sur ${data.palette}`,
  };
  const already = mode === "add" ? qtyOn(data.article_id, data.target) : 0;
  $("#inv-title").textContent = titles[mode];
  $("#inv-text").textContent =
    data.name +
    (mode.startsWith("move") ? `\nActuellement ${pieces(data.qty)} sur ${data.palette}` : "") +
    (mode === "add" && already ? `\nDéjà ${pieces(already)} sur cette palette` : "") +
    (mode === "edit" ? `\nActuellement ${pieces(data.qty)}` : "");
  $("#inv-pal-wrap").hidden = !needPal;
  $("#inv-pal").value = "P";
  $("#inv-qty-label").textContent = mode === "edit" ? "Quantité réelle" : mode.startsWith("move") ? "Pièces à déplacer" : "Pièces à ajouter";
  $("#inv-qty").value = mode === "edit" || mode.startsWith("move") ? String(data.qty) : "";
  $("#inv-remove").hidden = mode !== "edit";
  $("#inv-ok").textContent = mode.startsWith("move") ? "Déplacer" : mode === "edit" ? "Corriger" : "Ajouter";
  $("#inv-error").textContent = "";
  openModal("#modal-inv");
  setTimeout(() => (needPal ? $("#inv-pal") : $("#inv-qty")).focus(), 60);
}

function invFail(message) {
  $("#inv-error").textContent = message;
  replay($("#inv-error"), "shake");
}

async function submitInv(remove = false) {
  const a = invAction;
  if (!a) return;
  const qty = remove ? 0 : readQty($("#inv-qty"));
  const target = a.mode.endsWith("-new") ? paletteValue($("#inv-pal")) : a.target;
  try {
    if (a.mode.endsWith("-new") && !target) return invFail("Indiquez le numéro de palette.");
    if (a.mode === "edit") {
      await invApi("POST", "/api/inventory/set", { article_id: a.article_id, palette: a.palette, qty });
      toast(qty ? `${a.palette} : ${a.name} corrigé à ${pieces(qty)}.` : `${a.name} retiré de ${a.palette}.`);
    } else if (a.mode.startsWith("move")) {
      if (!qty) return invFail("Indiquez le nombre de pièces à déplacer.");
      if (qty > a.qty) return invFail(`Il n'y a que ${pieces(a.qty)} sur ${a.palette}.`);
      if (normPalette(target) === a.palette) return invFail("Choisissez une autre palette que celle de départ.");
      await invApi("POST", "/api/inventory/move", { article_id: a.article_id, from: a.palette, to: target, qty });
      toast(`${pieces(qty)} déplacée${qty > 1 ? "s" : ""} de ${a.palette} vers ${normPalette(target)}.`);
    } else {
      if (!qty) return invFail("Indiquez le nombre de pièces à ajouter.");
      const p = normPalette(target);
      await invApi("POST", "/api/inventory/set", { article_id: a.article_id, palette: p, qty: qtyOn(a.article_id, p) + qty });
      toast(`${pieces(qty)} de ${a.name} ajoutée${qty > 1 ? "s" : ""} sur ${p}.`);
    }
    invAction = null;
    closeModal($("#modal-inv"));
    await refreshInventory();
  } catch (err) {
    if (err.status !== 401) invFail(err.message);
  }
}

$("#inv-ok").addEventListener("click", () => submitInv(false));
$("#inv-remove").addEventListener("click", () => submitInv(true));
["#inv-qty", "#inv-pal"].forEach((sel) =>
  $(sel).addEventListener("keydown", (e) => {
    if (e.key !== "Enter") return;
    if (sel === "#inv-pal") $("#inv-qty").focus();
    else submitInv(false);
  })
);

// ----- Glissement vers la droite sur un article : « SUPPRIMER » (inventaire seulement) -----

const SWIPE_OPEN = 88; // largeur du bandeau, en unités de la maquette
let swipe = null;

invList.addEventListener("pointerdown", (e) => {
  const row = e.target.closest(".row");
  if (!row || e.target.closest(".grip")) return;
  const zone = row.parentElement.querySelector(".delete-zone");
  closeSwipes(zone);
  const base = zone.classList.contains("open") ? SWIPE_OPEN : 0;
  swipe = { zone, startX: e.clientX, startY: e.clientY, base, width: base, active: false };
});

invList.addEventListener("pointermove", (e) => {
  if (!swipe) return;
  const dx = (e.clientX - swipe.startX) / scale;
  if (!swipe.active) {
    if (Math.abs(e.clientY - swipe.startY) / scale > 8) return (swipe = null); // défilement vertical
    if (Math.abs(dx) < 5) return;
    swipe.active = true;
    swipe.zone.classList.remove("anim");
    invList.setPointerCapture(e.pointerId);
  }
  swipe.width = Math.max(0, Math.min(SWIPE_OPEN, swipe.base + dx));
  swipe.zone.style.width = `${swipe.width}px`;
});

function endSwipe() {
  if (!swipe) return;
  const { zone, width, active } = swipe;
  swipe = null;
  if (!active) {
    if (zone.classList.contains("open")) setOpen(zone, false);
    return;
  }
  setOpen(zone, width > SWIPE_OPEN / 2);
  // Empêche le « clic » de fin de glissement de sélectionner l'article
  invList.addEventListener("click", (ev) => ev.stopPropagation(), { capture: true, once: true });
}

invList.addEventListener("pointerup", endSwipe);
invList.addEventListener("pointercancel", endSwipe);

function setOpen(zone, open) {
  zone.classList.add("anim");
  zone.classList.toggle("open", open);
  zone.style.width = open ? `${SWIPE_OPEN}px` : "0";
}

function closeSwipes(except) {
  invList.querySelectorAll(".delete-zone.open").forEach((z) => z !== except && setOpen(z, false));
}

// ---------- Suppression globale d'un article (avec confirmation) ----------

let confirmAction = null;

async function askDeleteArticle(id) {
  try {
    const article = await api("GET", `/api/articles/${id}`);
    const total = article.palettes.reduce((s, p) => s + p.qty, 0);
    $("#confirm-title").textContent = `Supprimer « ${article.name} » ?`;
    $("#confirm-text").textContent = total
      ? `L'article sera retiré du catalogue. Il reste ${pieces(total)} en stock (${article.palettes
          .map((p) => `${p.palette} : ${p.qty}`)
          .join(", ")}), ce stock sera supprimé aussi.`
      : "L'article sera retiré du catalogue. Il n'a plus de stock.";
    confirmAction = async () => {
      await invApi("DELETE", `/api/articles/${id}`);
      invList.querySelector(`li[data-id="${id}"]`)?.classList.add("leave");
      await wait(180);
      for (const tab of ["RN", "OF"]) state.lists[tab] = state.lists[tab].filter((x) => x.id !== id);
      if (inv.selected === id) inv.selected = null;
      await refreshInventory();
      toast(`« ${article.name} » supprimé du catalogue.`);
    };
    openModal("#modal-confirm");
  } catch (err) {
    showError(err.message);
  }
}

$("#confirm-ok").addEventListener("click", async () => {
  closeModals();
  try {
    if (confirmAction) await confirmAction();
  } catch (err) {
    if (err.status !== 401) showError(err.message);
  }
  confirmAction = null;
});

// ---------- Historique ----------

const TYPES = {
  ajout_article: "Ajout d'article",
  suppression_article: "Suppression d'article",
  reception: "Réception",
  sortie: "Sortie",
  inventaire: "Correction d'inventaire",
  deplacement: "Déplacement",
  changement_palette: "Changement de palette",
  palette_videe: "Palette vidée",
};
let histType = "";

$("#hist-types").innerHTML =
  `<button class="chip active" data-type="">Tout</button>` +
  Object.entries(TYPES).map(([k, v]) => `<button class="chip" data-type="${k}">${v}</button>`).join("");

$("#hist-types").addEventListener("click", (e) => {
  const chip = e.target.closest(".chip");
  if (!chip) return;
  histType = chip.dataset.type;
  document.querySelectorAll("#hist-types .chip").forEach((c) => c.classList.toggle("active", c === chip));
  loadHistory();
});

$("#hist-search").addEventListener("input", () => {
  clearTimeout(loadHistory.timer);
  loadHistory.timer = setTimeout(loadHistory, 200);
});

function fmtDate(ts) {
  const d = new Date(ts);
  return isNaN(d) ? ts : d.toLocaleString("fr-FR", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" });
}

function histRowHtml(r, cls = "") {
  const diff = r.qty_before != null && r.qty_after != null ? r.qty_after - r.qty_before : null;
  const diffHtml = diff ? `<span class="${diff > 0 ? "up" : "down"}">${diff > 0 ? "+" : ""}${diff}</span>` : "";
  // Hors groupe, le PO / l'OF (et la date réelle) sont rappelés dans les détails
  const det = cls ? r.details : [docLabel(r.type, r.ref, r.doc_date), r.details].filter(Boolean).join(" · ");
  return `<div class="hist-row ${cls}">
    <span>${cls ? "↳" : esc(fmtDate(r.ts))}</span>
    <span class="pill ${esc(r.type)}">${esc(TYPES[r.type] || r.type)}</span>
    <span class="art">${esc(r.article_name)}</span>
    <span>${esc(r.palette || "")}</span>
    <span class="num">${r.qty_before ?? ""}</span>
    <span class="num">${r.qty_after ?? ""}</span>
    <span class="num">${diffHtml}</span>
    <span class="det">${esc(det || "")}</span>
  </div>`;
}

// « PO 1234 · reçue le 04/10/2026 » pour une réception, « OF 4521 » pour une sortie
function docLabel(type, ref, docDate) {
  if (!ref) return "";
  return [`${type === "reception" ? "PO" : "OF"} ${ref}`, docDate ? `reçue le ${fmtDay(docDate)}` : ""].filter(Boolean).join(" · ");
}

// Type affiché en tête de groupe : l'action principale de la validation
const GROUP_TYPE = ["ajout_article", "suppression_article", "sortie", "reception", "deplacement", "inventaire", "changement_palette", "palette_videe"];

function histGroupHtml(rows) {
  const type = GROUP_TYPE.find((t) => rows.some((r) => r.type === t)) || rows[0].type;
  const names = new Set(rows.map((r) => r.article_name));
  const withRef = rows.find((r) => r.ref);
  // « palette vidée » répète la sortie qui la précède : on ne la compte pas
  const total = rows
    .filter((r) => r.type !== "palette_videe" && r.qty_before != null && r.qty_after != null)
    .reduce((s, r) => s + r.qty_after - r.qty_before, 0);
  const what = [withRef ? docLabel(type, withRef.ref, withRef.doc_date) : "", names.size > 1 ? `${names.size} articles` : [...names][0]]
    .filter(Boolean)
    .join(" · ");
  return `<div class="hist-group">
    <div class="hist-row hist-group-head">
      <span>${esc(fmtDate(rows[0].ts))}</span>
      <span class="pill ${esc(type)}">${esc(TYPES[type] || type)}</span>
      <span class="art">${esc(what)}</span>
      <span></span><span></span><span></span>
      <span class="num">${total ? `<span class="${total > 0 ? "up" : "down"}">${total > 0 ? "+" : ""}${total}</span>` : ""}</span>
      <span class="det">${rows.length} ligne${rows.length > 1 ? "s" : ""}</span>
    </div>
    ${rows
      .slice()
      .reverse() // dans l'ordre où elles ont été faites
      .map((r) => histRowHtml(r, "sub"))
      .join("")}
  </div>`;
}

async function loadHistory() {
  try {
    const params = new URLSearchParams({ type: histType, q: $("#hist-search").value.trim() });
    const rows = await api("GET", `/api/history?${params}`);
    // Les lignes d'une même validation (même numéro de groupe) se suivent : on les rassemble
    const groups = [];
    for (const r of rows) {
      const last = groups[groups.length - 1];
      if (r.batch != null && last && last[0].batch === r.batch) last.push(r);
      else groups.push([r]);
    }
    $("#hist-body").innerHTML =
      `<div class="hist-head"><span>Date</span><span>Événement</span><span>Article</span><span>Palette</span><span>Avant</span><span>Après</span><span>Écart</span><span>Détails</span></div>` +
      groups
      .map((g, i) => {
        const html = g.length > 1 ? histGroupHtml(g) : histRowHtml(g[0]);
        if (!MOTION || i >= 20) return html;
        return html.replace(/^<div class="/, `<div style="animation-delay:${i * 15}ms" class="enter `);
      })
      .join("");
    $("#hist-empty").hidden = rows.length > 0;
  } catch (err) {
    showError(err.message);
  }
}

// ---------- Verrouillage de l'application ----------
// Mot de passe à l'ouverture ; verrouillage après 2 h sans interaction
// ou en touchant le grand logo Newrest au milieu de l'écran.

const APP_IDLE_MS = 2 * 60 * 60 * 1000;
let lastActivity = Date.now();

["pointerdown", "keydown", "input", "wheel"].forEach((ev) =>
  document.addEventListener(ev, () => (lastActivity = Date.now()), { capture: true, passive: true })
);

function lockApp() {
  closeModals();
  if (inv.token) lockInventory(false);
  $("#app-password").value = "";
  $("#app-password-error").textContent = "";
  const el = $("#app-lock");
  el.classList.remove("closing");
  el.hidden = false;
  replay(el, "fade-in");
  setTimeout(() => $("#app-password").focus(), 50);
}

async function unlockApp() {
  try {
    await api("POST", "/api/login", { password: $("#app-password").value });
    lastActivity = Date.now();
    const el = $("#app-lock");
    el.classList.add("closing");
    await wait(250);
    el.hidden = true;
    el.classList.remove("closing");
  } catch (err) {
    $("#app-password-error").textContent = err.message;
    replay($("#app-password-error"), "shake");
    $("#app-password").select();
  }
}

$("#app-unlock").addEventListener("click", unlockApp);
$("#app-password").addEventListener("keydown", (e) => e.key === "Enter" && unlockApp());
// Toucher le grand logo du milieu verrouille (il disparaît dès qu'une liste est en cours)
$("#lock-logo").addEventListener("click", lockApp);
setInterval(() => {
  if ($("#app-lock").hidden && Date.now() - lastActivity >= APP_IDLE_MS) lockApp();
}, 30000);
setTimeout(() => $("#app-password").focus(), 50);

// ---------- Démarrage ----------

render();
