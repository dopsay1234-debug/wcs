@echo off
REM Double-cliquer sur ce fichier pour lancer Stock Duty Free
cd /d "%~dp0"
where py >nul 2>nul && (py app.py & goto :fin)
where python >nul 2>nul && (python app.py & goto :fin)
echo.
echo Python n'est pas installe sur ce PC.
echo Installez-le depuis https://www.python.org/downloads/ (gros bouton jaune "Download Python"),
echo puis double-cliquez a nouveau sur LANCER.bat.
echo.
start https://www.python.org/downloads/
:fin
pause
