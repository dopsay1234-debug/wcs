"""Logique métier du stock Duty Free : catalogue, stock par palette, historique.

Toutes les écritures passent par ce module. Chaque opération publique tourne
dans une transaction : soit tout est enregistré, soit rien.
"""

import sqlite3
from contextlib import contextmanager
from datetime import date, datetime

# Types d'événements écrits dans l'historique
ARTICLE_CREE = "ajout_article"
ARTICLE_SUPPRIME = "suppression_article"
RECEPTION = "reception"
SORTIE = "sortie"
PALETTE_RENOMMEE = "changement_palette"
PALETTE_VIDEE = "palette_videe"
INVENTAIRE = "inventaire"
DEPLACEMENT = "deplacement"

SCHEMA = """
CREATE TABLE IF NOT EXISTS articles (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT NOT NULL UNIQUE COLLATE NOCASE,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS stock (
    article_id INTEGER NOT NULL REFERENCES articles(id) ON DELETE CASCADE,
    palette    TEXT NOT NULL COLLATE NOCASE,
    qty        INTEGER NOT NULL CHECK (qty > 0),
    PRIMARY KEY (article_id, palette)
);
CREATE TABLE IF NOT EXISTS history (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    ts           TEXT NOT NULL,
    type         TEXT NOT NULL,
    article_name TEXT NOT NULL,
    palette      TEXT,
    qty_before   INTEGER,
    qty_after    INTEGER,
    details      TEXT,
    batch        INTEGER,
    ref          TEXT,
    doc_date     TEXT
);
CREATE INDEX IF NOT EXISTS history_ts ON history(ts);
"""


class StockError(Exception):
    """Erreur métier affichable telle quelle à l'opérateur."""


def _now():
    return datetime.now().isoformat(timespec="seconds")


def _clean_name(name):
    name = " ".join(str(name or "").split())
    if not name:
        raise StockError("Le nom de l'article est obligatoire.")
    return name


def _clean_palette(palette):
    palette = "".join(str(palette or "").split()).upper()
    if not palette or palette == "P":  # « P » seul : le numéro n'a pas été tapé
        raise StockError("Le numéro de palette est obligatoire.")
    # "48" et "P48" désignent la même palette
    if palette.isdigit():
        palette = "P" + palette
    return palette


def _clean_date(value):
    """Date réelle de réception : AAAA-MM-JJ, pas dans le futur."""
    try:
        d = date.fromisoformat(str(value or "").strip())
    except ValueError:
        raise StockError("La date de réception est obligatoire.")
    if d > date.today():
        raise StockError("La date de réception ne peut pas être dans le futur.")
    return d.isoformat()


def _clean_qty(qty, allow_zero=False):
    try:
        qty = int(qty)
    except (TypeError, ValueError):
        raise StockError("Quantité invalide.")
    if qty < 0 or (qty == 0 and not allow_zero):
        raise StockError("La quantité doit être positive.")
    return qty


class Stock:
    def __init__(self, path):
        self.db = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA foreign_keys = ON")
        self.db.execute("PRAGMA journal_mode = WAL")
        self.db.executescript(SCHEMA)
        # Bases créées avant le regroupement de l'historique : on ajoute les colonnes manquantes
        cols = {r["name"] for r in self.db.execute("PRAGMA table_info(history)")}
        for col, typ in (("batch", "INTEGER"), ("ref", "TEXT"), ("doc_date", "TEXT")):
            if col not in cols:
                self.db.execute(f"ALTER TABLE history ADD COLUMN {col} {typ}")

    def close(self):
        self.db.close()

    @contextmanager
    def _tx(self):
        self.db.execute("BEGIN IMMEDIATE")
        # Toutes les lignes d'historique écrites dans cette transaction partagent ce numéro :
        # l'écran les regroupe (une validation, une création d'article…)
        self._batch = self.db.execute("SELECT COALESCE(MAX(batch), 0) + 1 FROM history").fetchone()[0]
        try:
            yield self.db
        except BaseException:
            self.db.execute("ROLLBACK")
            raise
        self.db.execute("COMMIT")

    def _log(self, db, type_, article_name, palette=None, before=None, after=None, details=None, ref=None, doc_date=None):
        db.execute(
            "INSERT INTO history (ts, type, article_name, palette, qty_before, qty_after, details, batch, ref, doc_date)"
            " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (_now(), type_, article_name, palette, before, after, details, self._batch, ref, doc_date),
        )

    def _article(self, db, article_id):
        row = db.execute("SELECT id, name FROM articles WHERE id = ?", (article_id,)).fetchone()
        if row is None:
            raise StockError("Article introuvable (il a peut-être été supprimé).")
        return row

    def _qty(self, db, article_id, palette):
        row = db.execute(
            "SELECT qty FROM stock WHERE article_id = ? AND palette = ?", (article_id, palette)
        ).fetchone()
        return row["qty"] if row else 0

    def _set_qty(self, db, article_id, palette, qty):
        if qty > 0:
            db.execute(
                "INSERT INTO stock (article_id, palette, qty) VALUES (?, ?, ?)"
                " ON CONFLICT (article_id, palette) DO UPDATE SET qty = excluded.qty",
                (article_id, palette, qty),
            )
        else:
            db.execute("DELETE FROM stock WHERE article_id = ? AND palette = ?", (article_id, palette))

    # ---- lecture ----

    def search(self, query="", limit=30):
        query = " ".join(str(query or "").split())
        rows = self.db.execute(
            "SELECT a.id, a.name, COALESCE(SUM(s.qty), 0) AS total, COUNT(s.palette) AS palettes"
            " FROM articles a LEFT JOIN stock s ON s.article_id = a.id"
            " WHERE a.name LIKE ? ESCAPE '\\'"
            " GROUP BY a.id"
            # Les noms qui commencent par la saisie passent en premier
            " ORDER BY (a.name LIKE ? ESCAPE '\\') DESC, a.name COLLATE NOCASE"
            " LIMIT ?",
            ("%" + _like(query) + "%", _like(query) + "%", limit),
        ).fetchall()
        return [dict(r) for r in rows]

    def article(self, article_id):
        row = self._article(self.db, article_id)
        palettes = self.db.execute(
            "SELECT palette, qty FROM stock WHERE article_id = ? ORDER BY palette", (article_id,)
        ).fetchall()
        return {"id": row["id"], "name": row["name"], "palettes": [dict(p) for p in palettes]}

    def history(self, type_=None, query="", limit=500):
        sql = "SELECT * FROM history WHERE 1 = 1"
        args = []
        if type_:
            sql += " AND type = ?"
            args.append(type_)
        query = " ".join(str(query or "").split())
        if query:
            sql += " AND (article_name LIKE ? ESCAPE '\\' OR palette LIKE ? ESCAPE '\\' OR ref LIKE ? ESCAPE '\\')"
            args += ["%" + _like(query) + "%"] * 3
        sql += " ORDER BY id DESC LIMIT ?"
        args.append(limit)
        return [dict(r) for r in self.db.execute(sql, args).fetchall()]

    # ---- écriture ----

    def create_article(self, name, palettes=()):
        """Crée un article, avec éventuellement ses premières palettes."""
        name = _clean_name(name)
        lines = []
        for p in palettes:
            palette, qty = str(p.get("palette") or "").strip(), p.get("qty")
            if not palette and not qty:
                continue  # ligne laissée vide dans la fenêtre
            lines.append((_clean_palette(palette), _clean_qty(qty)))
        with self._tx() as db:
            if db.execute("SELECT 1 FROM articles WHERE name = ?", (name,)).fetchone():
                raise StockError(f"L'article « {name} » existe déjà.")
            article_id = db.execute(
                "INSERT INTO articles (name, created_at) VALUES (?, ?)", (name, _now())
            ).lastrowid
            self._log(db, ARTICLE_CREE, name)
            for palette, qty in lines:
                before = self._qty(db, article_id, palette)
                self._set_qty(db, article_id, palette, before + qty)
                self._log(db, RECEPTION, name, palette, before, before + qty, "Création de l'article")
        return self.article(article_id)

    def delete_article(self, article_id):
        """Supprime l'article du catalogue, avec tout son stock."""
        with self._tx() as db:
            art = self._article(db, article_id)
            rows = db.execute(
                "SELECT palette, qty FROM stock WHERE article_id = ? ORDER BY palette", (article_id,)
            ).fetchall()
            total = sum(r["qty"] for r in rows)
            details = ", ".join(f"{r['palette']}: {r['qty']}" for r in rows) or "aucun stock"
            db.execute("DELETE FROM articles WHERE id = ?", (article_id,))
            self._log(db, ARTICLE_SUPPRIME, art["name"], None, total, 0, f"Stock perdu : {details}")

    def rename_palette(self, article_id, old, new):
        """Change le numéro d'une palette pour un article."""
        old, new = _clean_palette(old), _clean_palette(new)
        if old == new:
            return self.article(article_id)
        with self._tx() as db:
            art = self._article(db, article_id)
            qty = self._qty(db, article_id, old)
            if qty == 0:
                raise StockError(f"La palette {old} n'existe pas pour {art['name']}.")
            if self._qty(db, article_id, new):
                raise StockError(f"La palette {new} existe déjà pour {art['name']}.")
            db.execute(
                "UPDATE stock SET palette = ? WHERE article_id = ? AND palette = ?",
                (new, article_id, old),
            )
            self._log(db, PALETTE_RENOMMEE, art["name"], new, qty, qty, f"{old} → {new}")
        return self.article(article_id)

    def apply(self, kind, lines, ref=None, doc_date=None):
        """Applique une réception (RN) ou une sortie (OF) en une seule transaction.

        lines : [{"article_id": ..., "palette": ..., "qty": ...}]
        ref : numéro de PO (réception) ou d'OF (sortie), obligatoire.
        doc_date : date réelle de la réception (AAAA-MM-JJ), obligatoire pour une réception.
        Les lignes à 0 sont ignorées. Si une ligne est refusée, rien n'est enregistré.
        """
        if kind not in ("RN", "OF"):
            raise StockError("Type de mouvement inconnu.")
        ref = " ".join(str(ref or "").split()).upper() or None
        if not ref:
            raise StockError("Le numéro de PO est obligatoire pour une réception." if kind == "RN" else "Le numéro d'OF est obligatoire pour une sortie.")
        doc_date = _clean_date(doc_date) if kind == "RN" else None
        clean = []
        for line in lines:
            qty = _clean_qty(line.get("qty"), allow_zero=True)
            if qty:
                clean.append((line.get("article_id"), _clean_palette(line.get("palette")), qty))
        if not clean:
            raise StockError("Aucune quantité à enregistrer.")

        done = []
        with self._tx() as db:
            for article_id, palette, qty in clean:
                art = self._article(db, article_id)
                before = self._qty(db, article_id, palette)
                if kind == "RN":
                    after = before + qty
                    self._set_qty(db, article_id, palette, after)
                    self._log(db, RECEPTION, art["name"], palette, before, after, ref=ref, doc_date=doc_date)
                else:
                    if before == 0:
                        raise StockError(f"{art['name']} : la palette {palette} est vide ou n'existe plus.")
                    if qty > before:
                        raise StockError(
                            f"{art['name']} : impossible de sortir {qty} de la palette {palette},"
                            f" il n'en reste que {before}."
                        )
                    after = before - qty
                    self._set_qty(db, article_id, palette, after)
                    self._log(db, SORTIE, art["name"], palette, before, after, ref=ref)
                    if after == 0:
                        self._log(db, PALETTE_VIDEE, art["name"], palette, before, 0, ref=ref)
                done.append({"article": art["name"], "palette": palette, "before": before, "after": after})
        return done

    # ---- inventaire ----

    def inventory(self):
        """Contenu de chaque palette : [{palette, total, items: [{article_id, name, qty}]}]."""
        rows = self.db.execute(
            "SELECT s.palette, s.qty, a.id AS article_id, a.name FROM stock s JOIN articles a ON a.id = s.article_id"
            " ORDER BY a.name COLLATE NOCASE"
        ).fetchall()
        pallets = {}
        for r in rows:
            p = pallets.setdefault(r["palette"], {"palette": r["palette"], "total": 0, "items": []})
            p["items"].append({"article_id": r["article_id"], "name": r["name"], "qty": r["qty"]})
            p["total"] += r["qty"]
        return sorted(pallets.values(), key=lambda p: _palette_key(p["palette"]))

    def set_quantity(self, article_id, palette, qty):
        """Correction d'inventaire : fixe la quantité exacte d'un article sur une palette (0 = la retire)."""
        palette, qty = _clean_palette(palette), _clean_qty(qty, allow_zero=True)
        with self._tx() as db:
            art = self._article(db, article_id)
            before = self._qty(db, article_id, palette)
            if before == qty:
                return
            self._set_qty(db, article_id, palette, qty)
            self._log(db, INVENTAIRE, art["name"], palette, before, qty)
            if qty == 0:
                self._log(db, PALETTE_VIDEE, art["name"], palette, before, 0)

    def move(self, article_id, source, target, qty):
        """Déplace des pièces d'un article d'une palette à une autre."""
        source, target, qty = _clean_palette(source), _clean_palette(target), _clean_qty(qty)
        if source == target:
            raise StockError("La palette de départ et d'arrivée sont les mêmes.")
        with self._tx() as db:
            art = self._article(db, article_id)
            src = self._qty(db, article_id, source)
            if qty > src:
                raise StockError(f"{art['name']} : il n'y a que {src} pièce(s) sur {source}.")
            dst = self._qty(db, article_id, target)
            self._set_qty(db, article_id, source, src - qty)
            self._set_qty(db, article_id, target, dst + qty)
            self._log(db, DEPLACEMENT, art["name"], f"{source} → {target}", None, None, f"{qty} pièce(s) déplacée(s)")
            if src == qty:
                self._log(db, PALETTE_VIDEE, art["name"], source, src, 0)


def _palette_key(palette):
    """Tri naturel : P2 avant P10."""
    digits = "".join(c for c in palette if c.isdigit())
    return (int(digits) if digits else 0, palette)


def _like(text):
    return text.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
