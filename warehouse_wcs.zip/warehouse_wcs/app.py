"""Stock Duty Free : petit serveur local + interface web tactile.

Lancement : python app.py  (ou double-clic sur LANCER.bat)
Le navigateur s'ouvre tout seul sur http://127.0.0.1:8765.
La base de données stock.db est créée à côté du programme.
"""

import json
import mimetypes
import secrets
import time
import os
import re
import subprocess
import sys
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from stock import Stock, StockError

HOST = "127.0.0.1"
PORT = int(os.environ.get("STOCK_PORT", "8765"))

STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
DATA_DIR = os.path.dirname(os.path.abspath(__file__))

DB_PATH = os.environ.get("STOCK_DB", os.path.join(DATA_DIR, "stock.db"))

# Le registre Windows peut associer de mauvais types à ces extensions
mimetypes.add_type("text/javascript", ".js")
mimetypes.add_type("text/css", ".css")
mimetypes.add_type("image/svg+xml", ".svg")
mimetypes.add_type("font/woff2", ".woff2")
mimetypes.add_type("image/x-icon", ".ico")

stock = None
lock = threading.Lock()  # une seule écriture à la fois sur la connexion SQLite

# Écran de verrouillage de l'application
APP_PASSWORD = os.environ.get("STOCK_APP_PASSWORD", "Appro")

# Onglet Inventaire : mot de passe, puis jeton valable une heure
PASSWORD = os.environ.get("STOCK_PASSWORD", "Newrest2026")
SESSION_SECONDS = 3600
sessions = {}  # jeton -> heure d'expiration


def check_token(headers):
    token = headers.get("X-Token") or ""
    now = time.time()
    for t in [t for t, exp in sessions.items() if exp < now]:
        del sessions[t]
    if token not in sessions:
        raise Unauthorized("Session Inventaire expirée : entrez à nouveau le mot de passe.")


class Unauthorized(StockError):
    pass


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass  # console silencieuse

    def _send(self, status, body, content_type="application/json; charset=utf-8"):
        if not isinstance(body, bytes):
            body = json.dumps(body, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _body(self):
        length = int(self.headers.get("Content-Length") or 0)
        if not length:
            return {}
        try:
            return json.loads(self.rfile.read(length).decode("utf-8"))
        except ValueError:
            raise StockError("Requête invalide.")

    def _api(self, method):
        url = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(url.query).items()}
        path = url.path
        with lock:
            if method == "GET" and path == "/api/articles":
                return stock.search(q.get("q", ""), limit=100000 if q.get("all") else 30)
            if method == "POST" and path == "/api/articles":
                data = self._body()
                return stock.create_article(data.get("name"), data.get("palettes") or [])
            m = re.fullmatch(r"/api/articles/(\d+)", path)
            if m and method == "GET":
                return stock.article(int(m.group(1)))
            if m and method == "DELETE":
                check_token(self.headers)  # suppression réservée à l'onglet Inventaire
                stock.delete_article(int(m.group(1)))
                return {"ok": True}
            m = re.fullmatch(r"/api/articles/(\d+)/palettes", path)
            if m and method == "PUT":
                data = self._body()
                return stock.rename_palette(int(m.group(1)), data.get("old"), data.get("new"))
            if method == "POST" and path == "/api/movements":
                data = self._body()
                return {"lines": stock.apply(data.get("kind"), data.get("lines") or [], data.get("ref"), data.get("date"))}
            if method == "POST" and path == "/api/login":
                if not secrets.compare_digest(str(self._body().get("password") or ""), APP_PASSWORD):
                    raise Unauthorized("Mot de passe incorrect.")
                return {"ok": True}
            if method == "POST" and path == "/api/unlock":
                if not secrets.compare_digest(str(self._body().get("password") or ""), PASSWORD):
                    raise Unauthorized("Mot de passe incorrect.")
                token = secrets.token_hex(16)
                sessions[token] = time.time() + SESSION_SECONDS
                return {"token": token, "expires_in": SESSION_SECONDS}
            if method == "POST" and path == "/api/lock":
                sessions.pop(self.headers.get("X-Token") or "", None)
                return {"ok": True}
            if method == "GET" and path == "/api/inventory":
                check_token(self.headers)
                return stock.inventory()
            if method == "POST" and path == "/api/inventory/set":
                check_token(self.headers)
                data = self._body()
                stock.set_quantity(data.get("article_id"), data.get("palette"), data.get("qty"))
                return {"ok": True}
            if method == "POST" and path == "/api/inventory/move":
                check_token(self.headers)
                data = self._body()
                stock.move(data.get("article_id"), data.get("from"), data.get("to"), data.get("qty"))
                return {"ok": True}
            if method == "GET" and path == "/api/history":
                return stock.history(q.get("type") or None, q.get("q", ""))
        return None

    def _handle(self, method):
        if self.path.startswith("/api/"):
            try:
                result = self._api(method)
            except Unauthorized as e:
                return self._send(401, {"error": str(e)})
            except StockError as e:
                return self._send(400, {"error": str(e)})
            except Exception as e:  # ne jamais laisser l'écran sans réponse
                return self._send(500, {"error": f"Erreur interne : {e}"})
            if result is None:
                return self._send(404, {"error": "Introuvable"})
            return self._send(200, result)
        if method != "GET":
            return self._send(405, {"error": "Méthode non autorisée"})
        self._static()

    def _static(self):
        rel = urlparse(self.path).path.lstrip("/") or "index.html"
        full = os.path.normpath(os.path.join(STATIC_DIR, rel))
        if not full.startswith(os.path.normpath(STATIC_DIR) + os.sep) or not os.path.isfile(full):
            return self._send(404, b"Not found", "text/plain")
        ctype = mimetypes.guess_type(full)[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype.endswith("javascript"):
            ctype += "; charset=utf-8"
        with open(full, "rb") as f:
            self._send(200, f.read(), ctype)

    def do_GET(self):
        self._handle("GET")

    def do_POST(self):
        self._handle("POST")

    def do_PUT(self):
        self._handle("PUT")

    def do_DELETE(self):
        self._handle("DELETE")


def browser_paths():
    """Emplacements habituels de Chrome puis d'Edge sous Windows."""
    roots = [os.environ.get(k) for k in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA")]
    names = [r"Google\Chrome\Application\chrome.exe", r"Microsoft\Edge\Application\msedge.exe"]
    return [os.path.join(root, name) for name in names for root in roots if root]


def open_app(url):
    """Ouvre l'interface en plein écran, sans barre d'adresse ni onglets (mode kiosque).

    Un profil de navigateur dédié est utilisé : sinon, si Chrome est déjà ouvert,
    il ignorerait le mode kiosque et ouvrirait un simple onglet.
    Lancer avec --fenetre pour garder une fenêtre de navigateur normale.
    """
    if "--fenetre" not in sys.argv:
        profile = os.path.join(os.environ.get("LOCALAPPDATA") or DATA_DIR, "StockDutyFree", "navigateur")
        for exe in browser_paths():
            if os.path.isfile(exe):
                subprocess.Popen([
                    exe, "--kiosk", url,
                    f"--user-data-dir={profile}",
                    "--no-first-run", "--no-default-browser-check",
                    "--overscroll-history-navigation=0",  # pas de « page précédente » en glissant du doigt
                    "--disable-pinch",                    # pas de zoom à deux doigts
                    "--disable-features=Translate",
                    "--lang=fr",                          # dates et claviers à la française (jj/mm/aaaa)
                ])
                return
    webbrowser.open(url)


def main():
    global stock
    stock = Stock(DB_PATH)
    try:
        server = ThreadingHTTPServer((HOST, PORT), Handler)
    except OSError:
        # Déjà lancé : on ouvre simplement l'interface existante
        open_app(f"http://{HOST}:{PORT}")
        return
    url = f"http://{HOST}:{PORT}"
    print(f"Stock Duty Free lancé sur {url}")
    print(f"Base de données : {DB_PATH}")
    print("Plein écran : Alt+F4 pour fermer l'interface.")
    print("Fermez cette fenêtre pour arrêter l'application.")
    if "--no-browser" not in sys.argv:
        threading.Timer(0.5, open_app, (url,)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        stock.close()


if __name__ == "__main__":
    main()
